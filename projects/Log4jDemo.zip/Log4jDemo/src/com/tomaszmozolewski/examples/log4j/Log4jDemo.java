package com.tomaszmozolewski.examples.log4j;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Log4jDemo {
	private static Logger log = Logger.getLogger(Log4jDemo.class);
	
	public void doSomthing() {
		log.trace("Logging some trace message");
		log.debug("Logging some debug message");
		log.info("Logging some info message");
		log.warn("Logging some warn message");
		log.error("Logging some error message");
		log.fatal("Logging some fatal message");
	}
	
	public static void main(String[] args) {
		if (System.getProperty("server.root") == null) {
			System.err.println("Please set system property 'server.root' to location where you'd like log files to be written");
		}

		if (System.getProperty("com.citigroup.rel.websphere.env") == null) {
			System.err.println("Please set system property 'com.citigroup.rel.websphere.env' to dev, uat or prod");
		}
	
		new ClassPathXmlApplicationContext("conf/spring.xml");
		new Log4jDemo().doSomthing();
	}
}
