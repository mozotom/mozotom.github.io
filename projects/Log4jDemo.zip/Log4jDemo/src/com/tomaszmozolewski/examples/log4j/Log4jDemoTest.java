package com.tomaszmozolewski.examples.log4j;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Set following system properties
 * server.root - root for logging
 * com.citigroup.rel.websphere.env - environment: dev, uat, prod
 * @author Tomek
 *
 */
@SuppressWarnings("serial")
public class Log4jDemoTest {
	private static final String SPRING_CONFIG_FILE = "conf/spring.xml";
	private static final String LOG_ROOT = "server.root";
	private static final String ENV_PROP = "com.citigroup.rel.websphere.env";
	
	private static final String LOG_PATH = "/logs/Log4JDemoTest/";
	
	private static final Map<String, boolean[]> APP_ENVS = new HashMap<String, boolean[]>() {{
		put("dev", new boolean[] { true, true, true, true, true, false }); 
		put("uat", new boolean[] { true, true, true, true, false, false }); 
		put("prod", new boolean[] { true, true, false, false, false, false }); 
	}};
	
	private static final String[] LOG_MESSAGES = {
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some fatal message.*",
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some error message.*",
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some warn message.*",
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some info message.*",
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some debug message.*",
		".*com.tomaszmozolewski.examples.log4j.Log4jDemo - Logging some trace message.*"
	};
	
	
	@Test
	public void doSomethingTest() throws IOException {
		for (String appEnv: APP_ENVS.keySet()) {
			// Remove log file if exists
			File logFile = new File(LOG_PATH + appEnv +  File.separator + "applogs/Log4JDemo/log4jDemo.log");
			if (logFile.exists()) {
				assertTrue(logFile.delete());
			}
			
			// Setup environment 
			System.setProperty(ENV_PROP, appEnv);
			System.setProperty(LOG_ROOT, LOG_PATH + System.getProperty(ENV_PROP));
			new ClassPathXmlApplicationContext(SPRING_CONFIG_FILE);

			// Execute logging
			Log4jDemo log4jDemo = new Log4jDemo();
			log4jDemo.doSomthing();
			
			// Verify that correct log files have been written
			assertTrue(logFile.exists());
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(logFile));
			try {
				byte[] data = new byte[in.available()];
				in.read(data);
				String logString = new String(data).replaceAll("\r","").replaceAll("\n","");
				
				boolean[] logMask = APP_ENVS.get(appEnv);
				for (int i=0; i<logMask.length; ++i) {
					assertEquals(logMask[i], logString.matches(LOG_MESSAGES[i]));
				}
			} finally {
				in.close();
			}
		}
	}
}
