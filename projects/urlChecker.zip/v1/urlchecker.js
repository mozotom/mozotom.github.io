// Copyright Tomasz Mozolewski @2009

function showUrls(urls, p, w, h, c) {
  // p - protocol
  // w - width
  // h - height
  // c - columns

  outputHTML="<table border=\"1\"><tr>\n"
  urlsList = urls.split("\n")
  
  for (i=0; i<urlsList.length; ++i) {
    url = urlsList[i].replace(/[\r\n]/g,"")
    outputHTML += "<td width=\"" + w + "\" height=\"" + h + "\" style=\"text-align: center\">"
    outputHTML += "<a href=\"" + p + "://" + url + "\" target=\"_blank\">" + url + "</a><br />"
    outputHTML += "<iframe width=\"" + w + "\" height=\"" + h + "\" src=\"" + p + "://" + url + "\"></iframe>"
    outputHTML += "</td>\n"
    if ((i+1)%c == 0) outputHTML += "</tr><tr>\n"
  }
  outputHTML += "</tr></table>"
  output.innerHTML=outputHTML
}

