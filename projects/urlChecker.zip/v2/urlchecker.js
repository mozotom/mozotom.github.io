// Copyright Tomasz Mozolewski @2009

function showUrls(urls, p, w, h, c) {
  // p - protocol
  // w - width
  // h - height
  // c - columns
  
  parent.data_frame.location.href = "blank.html"
  urlsList = urls.split("\n")
  r = urlsList.length / c

  row_x = "*"
  for (i=1; i<r; ++i) row_x += ",*"
  outputHTML="<frameset rows=\"" + row_x + "\">\n"
  
  col_x = "*"
  for (i=1; i<c; ++i) col_x += ",*"
  outputHTML += "  <frameset cols=\"" + col_x + "\">\n"
  
  for (i=0; i<urlsList.length; ++i) {
    url = urlsList[i].replace(/[\r\n]/g,"")
    outputHTML += "    <frame src=\"" + p + "://" + url + "\"></frame>\n"
    if ((i+1)%c == 0) outputHTML += "  </frameset><frameset cols=\"" + col_x + "\">\n"
  }

  outputHTML += "  </frameset>\n"
  outputHTML += "</frameset>\n"
  parent.data_frame.document.writeln(outputHTML)
}

