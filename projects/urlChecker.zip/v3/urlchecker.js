// Copyright Tomasz Mozolewski @2009

function showUrls(urls, p, w, h, c) {
  // p - protocol
  // w - width
  // h - height
  // c - columns

  parent.data_frame.location.href = "blank.html"
  urlsList = urls.split("\n")
  r = urlsList.length / c

  row_x = "*"
  for (i=1; i<r; ++i) row_x += ",*"
  outputHTML="<frameset rows=\"" + row_x + "\">\n"
  
  col_x = "*"
  for (i=1; i<c; ++i) col_x += ",*"
  outputHTML += "  <frameset cols=\"" + col_x + "\">\n"

  for (i=0; i<urlsList.length; ++i) {
    outputHTML += "    <frame name=\"f" + i + "\" src=\"blank.html\"></frame>\n"
    if ((i+1)%c == 0) outputHTML += "  </frameset><frameset cols=\"" + col_x + "\">\n"
  }
  
  outputHTML += "  </frameset>\n"
  outputHTML += "</frameset>\n"
  parent.data_frame.document.writeln(outputHTML)
  
  for (i=0; i<urlsList.length; ++i) {
    url = urlsList[i].replace(/[\r\n]/g,"")
    parent.data_frame.frames[i].document.writeln("<frameset rows=\"25,*\"><frame src=\"blank.html\" scrolling=\"no\" /><frame src=\"" + p + "://" + url + "\" /></frameset>")
    parent.data_frame.frames[i].frames[0].document.writeln("<html><body style=\"text-align: center; background-color: yellow\"><a href=\"" + p + "://" + url + "\" target=\"_blank\">" + url + "</a></body></html>")
    parent.data_frame.frames[i].frames[0].document.body.style.margin = 0
  }
}

