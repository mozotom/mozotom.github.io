// Copyright Tomasz Mozolewski @2009


function showUrls(urls, p, m, w, h, c) {
  // p - protocol
  // m - method
  // w - width
  // h - height
  // c - columns

  outputHTML="<table border=\"1\" cellspacing=\"0\"><tr>\n"
  urlsList = urls.split("\n")
  
  for (i=0; i<urlsList.length; ++i) {
    url = urlsList[i].replace(/[\r\n]/g,"")
    if (url != "") {
      outputHTML += "<td width=\"" + w + "\" height=\"" + h + "\" style=\"text-align: center\">"
      outputHTML += "<table cellspacing=\"0\"><tr><td style=\"text-align: center; background: yellow\"><a href=\"" + p + "://" + url + "\" target=\"_blank\">" + url + "</a><br />"
      outputHTML += "</td></tr><tr></tr><td width=\"" + w + "\" height=\"" + h + "\" style=\"text-align: center\">"
      outputHTML += "<textarea id=\"tx" + i + "\" cols=\"" + w/8 + "\" rows=\"" + h/15 + "\"></textarea>"
      outputHTML += "</td></tr></table></td>\n"
    } else {
      outputHTML += "<td width=\"" + w + "\" height=\"" + h + "\" style=\"text-align: center; background: black; color: white\">"
      outputHTML += "BLANK URL!"
      outputHTML += "</td>\n"
    }
    if ((i+1)%c == 0) outputHTML += "</tr><tr>\n"
  }
  outputHTML += "</tr></table>"
  output.innerHTML=outputHTML
  
  for (i=0; i<urlsList.length; ++i) {
    url = urlsList[i].replace(/[\r\n]/g,"")
    if (url != "") {
      getContent(p + "://" + url, m, document.getElementById("tx" + i))
    }
  }
}

function getContent(url, method, dst) {
  var xmlhttp
  
  if (window.XMLHttpRequest) {
    // AJAX code for Mozilla, Safari, Opera etc.
    xmlhttp = new XMLHttpRequest()
  } else if (window.ActiveXObject)  {
    // AJAX code for IE
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
  }
  
  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      if (this.status == 200) {
        dst.value = this.responseText
        dst.style.background = "lightgreen"
      } else {
        dst.value = "Status code: " + this.status
        dst.style.background = "red"
        dst.style.color = "white"
      }
    }
  }

  xmlhttp.open("GET", url)
  xmlhttp.send()
}


